from django.shortcuts import render
from django.http import HttpResponse, JsonResponse

from polls.test import recommend_travel


# Create your views here.


def index(request):
    return render(request, 'myapp/index.html')
    # return HttpResponse("Hello, world. You're at the polls index.")


def process(request):
    data = request.POST.dict()
    arr = []
    for a in data:
        arr.append(data[a])
    if len(arr) < 5:
        return JsonResponse({
            'msg': "数据错误，没有五个数据"
        })

    arr[0] = int(arr[0])
    arr[1] = int(arr[1])
    arr[2] = int(arr[2])

    return JsonResponse(recommend_travel(*arr), safe=False)
