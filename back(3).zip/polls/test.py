#!/usr/bin/env python
# coding: utf-8
import json

# In[58]:
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

import pandas as pd

destinations = pd.read_csv('destinations(1).csv', encoding='gbk')

destinations.iloc[:, 2] = destinations.iloc[:, 2].astype(int)
destinations.head()

# In[59]:


from sklearn.feature_extraction.text import CountVectorizer

cv = CountVectorizer()

# 对文本列进行特征提取
text_matrix = cv.fit_transform(destinations['Others']).toarray()

# 将特征提取结果转换为DataFrame
text_df = pd.DataFrame(text_matrix, columns=cv.get_feature_names())

# 将特征提取结果与原始数据合并
result_df = pd.concat([destinations, text_df], axis=1)

# 把月份转换为季节
season_map = {1: 'Winter', 2: 'Winter', 3: 'Spring', 4: 'Spring', 5: 'Spring', 6: 'Summer', 7: 'Summer', 8: 'Summer',
              9: 'Autumn', 10: 'Autumn', 11: 'Autumn', 12: 'Winter'}
result_df['Season'] = result_df['Month'].map(season_map)

# 将季节和人员组成转换为One-Hot编码
one_hot_col_group = pd.get_dummies(result_df['Group'])
one_hot_col_season = pd.get_dummies(result_df['Season'])

# 将One-Hot编码与原始DataFrame进行合并
result_df = pd.concat([result_df, one_hot_col_season, one_hot_col_group], axis=1)

# 对旅游时长进行分类
bins = [0, 3, 7, float('inf')]  # 设定分箱边界
labels = ['1-3天（含3天）', '3-7天（含7天）', '7天以上']  # 设定每个箱的标签
result_df['Duration1'] = pd.cut(result_df['Duration'], bins=bins, labels=labels)  # 对col1进行分箱，新的一列名字为category

# 将分类后的旅游时长换为One-Hot编码
one_hot_col_duration = pd.get_dummies(result_df['Duration1'])

# 将One-Hot编码与原始DataFrame进行合并
result_df = pd.concat([result_df, one_hot_col_duration], axis=1)

result_df = result_df.drop(columns=['Others', 'Month', 'Group', 'Season', 'Duration1', 'Duration'])
# 把destination列放到最后
col_destination = result_df.pop('Destination')
result_df = result_df.join(col_destination)
result_df.head()

# In[60]:


import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer

cv = CountVectorizer()


def recommend_travel(Month, Duration, Expense, Group, Others):
    # 将用户提供的信息转换为DataFrame格式
    user_input = pd.DataFrame({
        'Month': [Month],
        'Duration': [Duration],
        'Expense': [Expense],
        'Group': [Group],
        'Others': [Others]
    })

    # 对文本列进行特征提取
    text_matrix = cv.fit_transform(user_input['Others']).toarray()

    # 将特征提取结果转换为DataFrame
    text_df = pd.DataFrame(text_matrix, columns=cv.get_feature_names())

    # 将特征提取结果与原始数据合并
    result_user = pd.concat([user_input, text_df], axis=1)

    # 把月份转换为季节
    season_map = {1: 'Winter', 2: 'Winter', 3: 'Spring', 4: 'Spring', 5: 'Spring', 6: 'Summer', 7: 'Summer',
                  8: 'Summer', 9: 'Autumn', 10: 'Autumn', 11: 'Autumn', 12: 'Winter'}
    result_user['Season'] = result_user['Month'].map(season_map)

    # 将季节和人员组成转换为One-Hot编码
    one_hot_col_group = pd.get_dummies(result_user['Group'])
    one_hot_col_season = pd.get_dummies(result_user['Season'])

    # 将One-Hot编码与原始DataFrame进行合并
    result_user = pd.concat([result_user, one_hot_col_season, one_hot_col_group], axis=1)

    # 对旅游时长进行分类
    bins = [0, 3, 7, float('inf')]  # 设定分箱边界
    labels = ['1-3天（含3天）', '3-7天（含7天）', '7天以上']  # 设定每个箱的标签
    result_user['Duration1'] = pd.cut(result_user['Duration'], bins=bins, labels=labels)  # 对col1进行分箱，新的一列名字为category

    # 将分类后的旅游时长换为One-Hot编码
    one_hot_col_duration = pd.get_dummies(result_user['Duration1'])

    # 将One-Hot编码与原始DataFrame进行合并
    result_user = pd.concat([result_user, one_hot_col_duration], axis=1)

    result_user = result_user.drop(columns=['Others', 'Month', 'Group', 'Season', 'Duration1', 'Duration'])

    # 将用户数据扩充至与模型长度一致
    yonghu = result_user.columns.tolist()
    moxing = result_df.columns.tolist()
    user = {}
    for i in moxing[:-1]:
        if i in yonghu:
            user[i] = user.get(i, 1)
        else:
            user[i] = user.get(i, 0)
    user = pd.Series(user)
    result_df_2 = result_df.drop(columns=['Destination'])

    # 将用户特征与旅游目的地特征进行比较，计算相似度
    user_similarity = cosine_similarity(user.values.reshape(1, -1), result_df_2)
    # print(user_similarity )
    # 找出相似度最高的目的地，向用户推荐
    top_destinations = result_df.loc[np.argsort(user_similarity).reshape(-1)[-1:], 'Destination']
    recommended_destinations = destinations.loc[destinations['Destination'].isin(top_destinations)]

    return json.loads(recommended_destinations.iloc[:, -1][::-1].drop_duplicates().to_json())


# Month = 8
# Duration = 12
# Expense = 6000
# Group = '家人'
# Others = '体育比赛 公园 飞'  # 这些是我们自定义的例子
# a = [Month, Duration, Expense, Group, Others]  # 前端的结果需要得到这个形式
# user = recommend_travel(*a)
# print(user)

# In[61]:






# In[ ]:




